floresta={

};

function onEnter()
io.write("Voc� entrou na floresta")
end

floresta.nome = "Floresta Negra"
floresta.descricao = "Voc� entrou na floresta negra... ela � um pouco assustadora"

floresta.onEnter = onEnter;
