----
--Knight NPC
---
--Create a knight Table--
knight = {};
knight.description = "Um cavaleiro alto com uma armadura dourada, Ele aparenta est� amedrontado.";
knight.name = "O Cavaleiro";
function knight.OnTalk()
end;

knigth.OnTalk = OnTalk
